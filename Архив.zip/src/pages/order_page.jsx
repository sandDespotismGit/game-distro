import { VStack } from "@chakra-ui/react";

const OrderPage = () => {
  return <VStack></VStack>;
};

export default OrderPage;
