const base_url = "http://212.41.9.251:8013/api";

export default base_url;
